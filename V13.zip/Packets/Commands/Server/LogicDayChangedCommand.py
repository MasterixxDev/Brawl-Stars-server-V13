from Database.DatabaseManager import DataBase
from Logic.EventSlots import EventSlots

from Utils.Writer import Writer

class LogicDayChangedCommand(Writer):

    def __init__(self, client, player):
        super().__init__(client)
        self.id = 24111
        self.player = player

    def encode(self):
        EventSlots.SetEventClaimed(self)