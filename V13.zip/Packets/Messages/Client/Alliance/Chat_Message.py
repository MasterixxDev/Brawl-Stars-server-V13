from Packets.Messages.Server.Alliance.Alliance_Chat_Server_Message import AllianceChatServerMessage
from Packets.Messages.Server.AllianceBot.Alliance_Bot_Chat_Server_Message import AllianceBotChatServerMessage
from Packets.Messages.Server.Out_Of_Sync_Message import OutOfSyncMessage
from Database.DatabaseManager import DataBase

from Utils.Reader import BSMessageReader


class Chat_Message(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client
        self.bot_msg = ''
        self.send_ofs = False
        self.IsAcmd = False

    def decode(self):
        self.msg = self.read_string()

        if self.msg.lower() == '/stats':
            self.bot_msg = f'Статус сервера:\nВерсия сборки: 1.1 (для V15.140)\nFingerprint SHA: {self.player.patch_sha}'
            self.IsAcmd = True

        elif self.msg.lower() == '/help':
            self.bot_msg = 'Команды клуба\n/stats - показать статус сервера
            self.IsAcmd = True

        else:
            self.IsAcmd = False



    def process(self, crypter):
        if self.IsAcmd == False:
            DataBase.Addmsg(self, 2, 0, self.player.low_id, self.player.name, self.player.club_role, self.msg)
            DataBase.loadClub(self, self.player.club_low_id)
            for i in self.plrids:
                AllianceChatServerMessage(self.client, self.player, self.msg).sendWithLowID(i)

        if self.bot_msg != '':
            AllianceBotChatServerMessage(self.client, self.player, self.bot_msg).send(crypter)

        if self.send_ofs:
            OutOfSyncMessage(self.client, self.player, 'Changes have been applied').send(crypter)