from Utils.Writer import Writer
from Packets.Messages.Server.Battle.UDPConnectionInfo import UDPConnectionInfo
from Logic.Battles.Battle import Battle

class MatchmakingInfoMessage(Writer):
    def __init__(self, client, player):
        super().__init__(client)
        self.id = 20405
        self.player = player
        self.client = client

    def encode(self):
        self.writeInt(0) #second
        self.writeInt(2) #сколько надо
        self.writeInt(2) # сколько в подборе
        self.writeInt(0)
        self.writeInt(0) 
        self.writeBoolean(True) #show Tips
        
    #def process(self, crypter):
        
        print("подключаем")
        UDPConnectionInfo(self.client, self.player).send(crypter)
        print("успешно!")
        
        print("бабка")
        battle = Battle(self.client, self.player)
        battle.start()