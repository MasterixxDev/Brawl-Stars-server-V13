from Utils.Writer import Writer
from Database.DatabaseManager import DataBase
from Logic.Player import Players
from Logic.Battles.GameObjects import GameObjects
from Utils.BitStream import BitStream

class VisionUpdate(Writer):

    def __init__(self, client, player):
        super().__init__(client)
        self.id = 24109
        self.player = player

    def encode(self):
        self.writeVint(self.player.battleTick)
        self.writeVint(self.player.dudu)
        self.writeVint(0)
        self.writeVint(6974)
        self.writeBoolean(True) #Live

        stream = BitStream()
        
        GameObjects.encode(stream, self)
        stream.writePositiveInt(0, 8)
        
        self.writeBytes(stream.getBuff())