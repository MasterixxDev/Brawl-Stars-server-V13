from Utils.Writer import Writer
from Database.DatabaseManager import DataBase

class TeamGameroomDataMessage(Writer):
    MAX_PLAYERS = 3  # Максимальное количество игроков в комнате
    
    def __init__(self, client, player):
        super().__init__(client)
        self.id = 24124
        self.player = player
        self.player_count = 1  # Начальное количество игроков

    def encode(self):
        DataBase.loadGameroom(self)
        self._prepare_player_data()
        
        if self.player.room_id != 0:
            self._write_room_header()
            self._write_room_info()
            self._write_players_data()
            self._write_room_footer()
        else:
            print(f"Invalid room ID: {self.player.room_id}")

    def _prepare_player_data(self):
        """Подготавливает данные игрока"""
        self.brawler_trophies = self.player.brawlers_trophies[str(self.player.brawler_id)]
        self.brawler_trophies_for_rank = self.player.brawlers_trophies_in_rank[str(self.player.brawler_id)]
        
        if self.player.Brawler_starPower[str(self.player.brawler_id)] >= 1:
            self.brawler_level = self.player.Brawler_level[str(self.player.brawler_id)] + 2
        else:
            self.brawler_level = self.player.Brawler_level[str(self.player.brawler_id)] + 1

    def _write_room_header(self):
        """Записывает заголовок комнаты"""
        self.writeVint(1)  # mode
        self.writeVint(0)
        self.writeVint(1)
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(0)

    def _write_room_info(self):
        """Записывает основную информацию о комнате"""
        self.writeInt(self.player.room_id)
        self.writeVint(1557129593)
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(self.player.slot_index)
        self.writeScId(15, self.mapID)  # MapID
        print(f"Map ID: {self.mapID}")
        
        # Обновляем количество игроков на основе фактических данных
        self.player_count = min(len(self.playersdata), self.MAX_PLAYERS)
        self.writeVint(self.player_count)

    def _write_player_data(self, player_data):
        """Записывает данные одного игрока"""
        self.writeVint(player_data["IsHost"])  # Gameroom owner boolean
        self.writeInt(0)  # HighID
        self.writeInt(int(player_data["LowID"]))  # LowID
        self.writeString(player_data["name"])  # Player name
        self.writeVint(3)

        self.writeScId(16, self.player.brawler_id)  # BrawlerID
        self.writeScId(29, self.player.skin_id)
        self.writeVint(self.brawler_trophies)
        self.writeVint(self.brawler_trophies_for_rank)
        self.writeVint(self.brawler_level)

        self.writeVint(3)  # Player State
        self.writeVint(player_data["Ready"])  # Is ready
        self.writeVint(player_data["Team"])  # Team | 0: Blue, 1: Red

    def _write_players_data(self):
        """Записывает данные всех игроков (до MAX_PLAYERS)"""
        for i, (player, values) in enumerate(self.playersdata.items()):
            if i >= self.MAX_PLAYERS:
                break
            self._write_player_data(values)

    def _write_room_footer(self):
        """Записывает завершающие данные комнаты"""
        self.writeVint(0)
        self.writeVint(0)
        self.writeBoolean(False)
