from Utils.Writer import Writer
from Database.DatabaseManager import DataBase

class GetBrawlerLocalMessage(Writer):

    def __init__(self, client, player, players, brawler, type):
        super().__init__(client)
        self.id = 24403
        self.player = player
        self.brawler = brawler
        self.players = players
        self.type = type
        
    	
    def encode(self):
        self.indexOfPlayer = 1

        self.writeVint(0)
        #self.writeVint(0)
        self.writeScId(16, self.brawler)
        print(f"brawler: {self.brawler}")
        self.writeString()
        self.writeVint(len(self.players)) #count

        for player in self.players:
            if player["lowID"] == self.player.low_id:
                self.indexOfPlayer = self.players.index(player) + 1   	
        self.writeVint(0) # High ID
        self.writeVint(player["lowID"]) # Low ID
        self.writeVint(1)
        self.writeVint(player['brawlersTrophies'][str(self.brawler)]) # Player Trophies
        self.writeVint(1)
        self.writeString()
            	
        self.writeString(player['name'])# Player Name
        self.writeVint(player['playerExp']) # Player Level
       # self.writeVint(28000000 + player['profileIcon'])
        self.writeVint(28 + player['profileIcon'])
        self.writeVint(0) # Unknown


        self.writeVint(0)
        self.writeVint(self.indexOfPlayer)
        self.writeVint(0) #type
        self.writeVint(0) # Leaderboard global TID
        self.writeString("RO")