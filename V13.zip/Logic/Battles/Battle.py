from Packets.Messages.Server.Battle.VisionUpdate import VisionUpdate
from Packets.Messages.Server.Battle.StartLoadingMessage import StartLoadingMessage
from Packets.Messages.Server.Battle.UDPConnectionInfo import UDPConnectionInfo

import time
from threading import Thread

class Battle(Thread):
    def __init__(self, client, player):
        Thread.__init__(self)
        self.client = client
        self.player = player
        self.subTick = 0
        self.tick = 0
        self.started = 0
        print("Battle Sent!")
    
    def run(self):
        self.startBattle(crypter)
    
    def startBattle(self, crypter):
        self.started = 1
        print("online pack sent!")
        StartLoadingMessage(self.client, self.player).send(crypter)
        UDPConnectionInfo(self.client, self.player).send(crypter)
        while self.started:
            if True:#self.subTick >= 4:
                self.tick += 1
                self.subTick = 0
                self.player.battleTick = self.tick
                #print("Tick: ", self.tick)
            self.process()
            time.sleep(0.045)

    def process(self, crypter):
        print("VisionUpdate Sent!")
        VisionUpdate(self.client, self.player).send(crypter)
        #self.subTick += 1